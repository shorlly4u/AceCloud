
import { GoogleGenAI } from "@google/genai";

if (!process.env.API_KEY) {
  console.warn("API_KEY environment variable not set. AI features will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

export const summarizeDocument = async (documentContent: string): Promise<string> => {
  if (!process.env.API_KEY) {
    return Promise.resolve("AI summarization is disabled. API key is not configured.");
  }
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `You are a legal assistant. Summarize the key points of the following legal document clearly and concisely for a lawyer to review quickly. Focus on parties involved, key obligations, dates, and any financial amounts mentioned. Document content:\n\n---\n\n${documentContent}`,
    });
    return response.text;
  } catch (error) {
    console.error("Error summarizing document with Gemini API:", error);
    return "Could not generate summary due to an API error.";
  }
};
