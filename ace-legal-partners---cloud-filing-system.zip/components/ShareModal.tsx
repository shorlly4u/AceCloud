
import React, { useState, useEffect } from 'react';
import Modal from './Modal';

type ShareMethod = 'link' | 'pin';

export type ShareDetails = 
  | { method: 'link'; expiration: string; usePassword: boolean; }
  | { method: 'pin'; email: string; };

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  onShare: (details: ShareDetails) => void;
  documentName: string;
}

const ShareModal: React.FC<ShareModalProps> = ({ isOpen, onClose, onShare, documentName }) => {
  const [shareMethod, setShareMethod] = useState<ShareMethod>('link');
  const [usePassword, setUsePassword] = useState(true);
  const [password, setPassword] = useState('');
  const [link, setLink] = useState('');
  const [expiration, setExpiration] = useState('72h');
  const [recipientEmail, setRecipientEmail] = useState('');
  
  const [linkCopied, setLinkCopied] = useState(false);
  const [passwordCopied, setPasswordCopied] = useState(false);
  const [error, setError] = useState('');

  const generateRandomString = (length: number) => {
    return [...Array(length)].map(() => (~~(Math.random() * 36)).toString(36)).join('');
  };

  useEffect(() => {
    if (isOpen) {
      setLink(`https://acelegal.sl/shared/${generateRandomString(16)}`);
      setPassword(generateRandomString(8));
      setLinkCopied(false);
      setPasswordCopied(false);
      setError('');
      setRecipientEmail('');
    }
  }, [isOpen]);

  const copyToClipboard = (text: string, type: 'link' | 'password') => {
    navigator.clipboard.writeText(text);
    if (type === 'link') {
      setLinkCopied(true);
      setTimeout(() => setLinkCopied(false), 2000);
    } else {
      setPasswordCopied(true);
      setTimeout(() => setPasswordCopied(false), 2000);
    }
  };
  
  const handleConfirmShare = () => {
    setError('');
    if (shareMethod === 'pin' && (!recipientEmail || !/\S+@\S+\.\S+/.test(recipientEmail))) {
        setError('Please enter a valid recipient email address.');
        return;
    }

    if (shareMethod === 'link') {
        onShare({ method: 'link', expiration, usePassword });
    } else {
        onShare({ method: 'pin', email: recipientEmail });
    }
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Share Document: ${documentName}`}>
      <div className="space-y-4">
        <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Sharing Method</label>
            <div className="flex rounded-md shadow-sm">
                <button
                    type="button"
                    onClick={() => setShareMethod('link')}
                    className={`relative inline-flex items-center px-4 py-2 rounded-l-md border text-sm font-medium focus:z-10 focus:outline-none focus:ring-1 focus:ring-brand-secondary ${shareMethod === 'link' ? 'bg-brand-secondary text-white border-brand-secondary' : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'}`}
                >
                    Expiring Link
                </button>
                <button
                    type="button"
                    onClick={() => setShareMethod('pin')}
                    className={`-ml-px relative inline-flex items-center px-4 py-2 rounded-r-md border text-sm font-medium focus:z-10 focus:outline-none focus:ring-1 focus:ring-brand-secondary ${shareMethod === 'pin' ? 'bg-brand-secondary text-white border-brand-secondary' : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'}`}
                >
                    One-Time PIN
                </button>
            </div>
        </div>

        {shareMethod === 'link' && (
          <div className="space-y-4 p-4 border rounded-md bg-gray-50">
            <div>
              <label className="block text-sm font-medium text-gray-700">Secure Link</label>
              <div className="mt-1 flex rounded-md shadow-sm">
                <input type="text" readOnly value={link} className="flex-1 block w-full min-w-0 rounded-none rounded-l-md sm:text-sm border-gray-300 bg-gray-100 p-2" />
                <button onClick={() => copyToClipboard(link, 'link')} className="relative -ml-px inline-flex items-center space-x-2 px-4 py-2 border border-gray-300 text-sm font-medium rounded-r-md text-gray-700 bg-gray-200 hover:bg-gray-300">
                  <span>{linkCopied ? 'Copied!' : 'Copy'}</span>
                </button>
              </div>
            </div>

            <div className="flex items-start">
                <div className="flex items-center h-5">
                    <input id="usePassword" name="usePassword" type="checkbox" checked={usePassword} onChange={(e) => setUsePassword(e.target.checked)} className="focus:ring-brand-secondary h-4 w-4 text-brand-secondary border-gray-300 rounded" />
                </div>
                <div className="ml-3 text-sm">
                    <label htmlFor="usePassword" className="font-medium text-gray-700">Require Password</label>
                </div>
            </div>
            
            {usePassword && (
              <div>
                <label className="block text-sm font-medium text-gray-700">Generated Password</label>
                <div className="mt-1 flex rounded-md shadow-sm">
                  <input type="text" readOnly value={password} className="flex-1 block w-full min-w-0 rounded-none rounded-l-md sm:text-sm border-gray-300 bg-gray-100 p-2" />
                  <button onClick={() => copyToClipboard(password, 'password')} className="relative -ml-px inline-flex items-center space-x-2 px-4 py-2 border border-gray-300 text-sm font-medium rounded-r-md text-gray-700 bg-gray-200 hover:bg-gray-300">
                    <span>{passwordCopied ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>
              </div>
            )}
            
            <div>
                <label htmlFor="expiration" className="block text-sm font-medium text-gray-700">Link Expires In</label>
                <select id="expiration" value={expiration} onChange={e => setExpiration(e.target.value)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-brand-secondary focus:border-brand-secondary sm:text-sm rounded-md">
                    <option value="24h">24 Hours</option>
                    <option value="72h">72 Hours</option>
                    <option value="7d">7 Days</option>
                </select>
            </div>
          </div>
        )}

        {shareMethod === 'pin' && (
            <div className="space-y-4 p-4 border rounded-md bg-gray-50">
                 <div>
                    <label htmlFor="recipient-email" className="block text-sm font-medium text-gray-700">Recipient's Email</label>
                    <input
                        type="email"
                        id="recipient-email"
                        value={recipientEmail}
                        onChange={(e) => setRecipientEmail(e.target.value)}
                        className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-brand-secondary focus:border-brand-secondary sm:text-sm"
                        placeholder="e.g., third.party@example.com"
                    />
                    {error && <p className="mt-1 text-sm text-red-600">{error}</p>}
                </div>
                <p className="text-xs text-gray-500">
                    A secure, single-use PIN will be sent to the recipient. They will need to enter the PIN to access the document. The session will expire after 30 minutes.
                </p>
            </div>
        )}
      </div>
      <div className="pt-6 flex justify-end space-x-3">
        <button type="button" onClick={onClose} className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-secondary">
          Cancel
        </button>
        <button type="button" onClick={handleConfirmShare} className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-brand-secondary hover:bg-opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-secondary">
          Confirm Share & Close
        </button>
      </div>
    </Modal>
  );
};

export default ShareModal;