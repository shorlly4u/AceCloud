
import React, { useState } from 'react';
import Modal from './Modal';
import { UserRole } from '../types';

interface InviteUserModalProps {
  isOpen: boolean;
  onClose: () => void;
  onInvite: (email: string, role: UserRole) => void;
}

const InviteUserModal: React.FC<InviteUserModalProps> = ({ isOpen, onClose, onInvite }) => {
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<UserRole>(UserRole.Client);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email.trim() || !/\S+@\S+\.\S+/.test(email)) {
      setError('A valid email address is required.');
      return;
    }
    
    // Enforce domain validation for staff roles
    const staffRoles = [UserRole.Lawyer, UserRole.Admin, UserRole.Secretary];
    if (staffRoles.includes(role) && !email.endsWith('@acelegal.sl')) {
        setError('Staff members must have an @acelegal.sl email address.');
        return;
    }

    onInvite(email, role);
    // Reset form for next time
    setEmail('');
    setRole(UserRole.Client);
  };

  const handleClose = () => {
    // Reset form state on close
    setEmail('');
    setRole(UserRole.Client);
    setError('');
    onClose();
  }

  return (
    <Modal isOpen={isOpen} onClose={handleClose} title="Invite New User">
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && <p className="text-sm text-red-600 bg-red-100 p-3 rounded-md">{error}</p>}
        <div>
          <label htmlFor="user-email" className="block text-sm font-medium text-gray-700">
            Email Address
          </label>
          <input
            type="email"
            id="user-email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-brand-secondary focus:border-brand-secondary sm:text-sm"
            placeholder="e.g., new.user@example.com"
          />
        </div>
        
        <div>
          <label htmlFor="user-role" className="block text-sm font-medium text-gray-700">
            Assign Role
          </label>
          <select
            id="user-role"
            value={role}
            onChange={(e) => setRole(e.target.value as UserRole)}
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-brand-secondary focus:border-brand-secondary sm:text-sm rounded-md"
          >
            <option value={UserRole.Client}>Client</option>
            <option value={UserRole.Lawyer}>Lawyer</option>
            <option value={UserRole.Admin}>Admin</option>
          </select>
        </div>

        <div className="pt-4 flex justify-end space-x-3">
          <button
            type="button"
            onClick={handleClose}
            className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-secondary"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-brand-secondary hover:bg-opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-secondary"
          >
            Send Invitation
          </button>
        </div>
      </form>
    </Modal>
  );
};

export default InviteUserModal;
