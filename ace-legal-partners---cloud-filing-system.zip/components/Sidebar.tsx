
import React from 'react';
import { UserRole } from '../types';

interface SidebarProps {
  role: UserRole;
  currentView: 'dashboard' | 'admin' | 'settings';
  onSetView: (view: 'dashboard' | 'admin' | 'settings') => void;
}

const CloudLegalLogo: React.FC<{ className?: string }> = ({ className }) => (
    <svg
        viewBox="0 0 100 80"
        className={className}
        xmlns="http://www.w3.org/2000/svg"
    >
        <g stroke="currentColor" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" fill="none">
            {/* Cloud Outline */}
            <path d="M 65,15 C 60,2.5 40,2.5 35,15 C 20,15 15,30 25,40 L 75,40 C 85,30 80,15 65,15 Z" />
            {/* Scales of Justice inside the cloud */}
            <g transform="translate(0, 5)">
                <path d="M 50,40 L 50,65" />
                <path d="M 30,40 L 70,40" />
                <path d="M 35,45 L 35,40" />
                <path d="M 65,45 L 65,40" />
                <path d="M 25,55 C 25,60 45,60 45,55" />
                <path d="M 55,55 C 55,60 75,60 75,55" />
            </g>
        </g>
    </svg>
);


const NavLink: React.FC<{ icon: React.ReactNode; label: string; isActive: boolean; onClick: () => void; }> = ({ icon, label, isActive, onClick }) => (
    <button 
        onClick={onClick} 
        className={`flex items-center w-full px-4 py-3 text-left rounded-md transition-colors duration-200 ${
            isActive 
            ? 'bg-brand-secondary text-white' 
            : 'text-gray-300 hover:bg-brand-secondary hover:text-white'
        }`}
    >
        {icon}
        <span className="ml-3 font-medium">{label}</span>
    </button>
);

const DashboardIcon = () => <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>;
const AdminIcon = () => <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M15 21a6 6 0 00-9-5.197m0 0A5.995 5.995 0 0012 12a5.995 5.995 0 00-3-5.197m12 0a4 4 0 110 5.292" /></svg>;
const SettingsIcon = () => <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37a1.724 1.724 0 002.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>;
const HelpIcon = () => <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;


const Sidebar: React.FC<SidebarProps> = ({ role, currentView, onSetView }) => {
  return (
    <aside className="w-64 flex-shrink-0 bg-brand-blue flex flex-col">
      <div className="h-20 flex items-center justify-center px-4">
        <div className="flex items-center text-white">
            <CloudLegalLogo className="w-12 h-12 text-brand-accent" />
            <span className="ml-2 text-xl font-bold tracking-tight">Ace Legal</span>
        </div>
      </div>
      <nav className="flex-1 px-4 py-4 space-y-2">
        <NavLink 
            icon={<DashboardIcon />} 
            label="Dashboard" 
            isActive={currentView === 'dashboard'} 
            onClick={() => onSetView('dashboard')} 
        />
        {role === UserRole.Admin && (
            <NavLink 
                icon={<AdminIcon />} 
                label="Admin Console" 
                isActive={currentView === 'admin'} 
                onClick={() => onSetView('admin')} 
            />
        )}
        {(role === UserRole.Lawyer || role === UserRole.Admin) && (
            <NavLink 
                icon={<SettingsIcon />} 
                label="Settings" 
                isActive={currentView === 'settings'} 
                onClick={() => onSetView('settings')} 
            />
        )}
      </nav>
      <div className="px-4 pb-4">
        <button className="flex items-center w-full px-4 py-3 text-left rounded-md text-gray-300 hover:bg-brand-secondary hover:text-white transition-colors duration-200">
            <HelpIcon />
            <span className="ml-3 font-medium">Help & Support</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
