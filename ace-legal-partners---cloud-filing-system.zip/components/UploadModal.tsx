
import React, { useState } from 'react';
import Modal from './Modal';
import { DocumentFile } from '../types';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUpload: (documentData: { name: string; type: DocumentFile['type']; tags: string[], status: DocumentFile['status'] }) => void;
}

const UploadModal: React.FC<UploadModalProps> = ({ isOpen, onClose, onUpload }) => {
  const [name, setName] = useState('');
  const [type, setType] = useState<DocumentFile['type']>('PDF');
  const [status, setStatus] = useState<DocumentFile['status']>('Draft');
  const [tags, setTags] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Document name is required.');
      return;
    }
    setError('');
    const tagsArray = tags.split(',').map(t => t.trim()).filter(Boolean);
    onUpload({ name, type, tags: tagsArray, status });
    // Reset form for next time
    setName('');
    setType('PDF');
    setStatus('Draft');
    setTags('');
  };

  const handleClose = () => {
    // Reset form state on close
    setName('');
    setType('PDF');
    setStatus('Draft');
    setTags('');
    setError('');
    onClose();
  }

  return (
    <Modal isOpen={isOpen} onClose={handleClose} title="Upload New Document">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="doc-name" className="block text-sm font-medium text-gray-700">
            Document Name
          </label>
          <input
            type="text"
            id="doc-name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-brand-secondary focus:border-brand-secondary sm:text-sm"
            placeholder="e.g., Preliminary Hearing Request"
          />
           {error && <p className="mt-1 text-sm text-red-600">{error}</p>}
        </div>
        <div className="grid grid-cols-2 gap-4">
            <div>
              <label htmlFor="doc-type" className="block text-sm font-medium text-gray-700">
                Document Type
              </label>
              <select
                id="doc-type"
                value={type}
                onChange={(e) => setType(e.target.value as DocumentFile['type'])}
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-brand-secondary focus:border-brand-secondary sm:text-sm rounded-md"
              >
                <option>PDF</option>
                <option>Word</option>
                <option>Image</option>
                <option>Correspondence</option>
                <option>Other</option>
              </select>
            </div>
             <div>
              <label htmlFor="doc-status" className="block text-sm font-medium text-gray-700">
                Initial Status
              </label>
              <select
                id="doc-status"
                value={status}
                onChange={(e) => setStatus(e.target.value as DocumentFile['status'])}
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-brand-secondary focus:border-brand-secondary sm:text-sm rounded-md"
              >
                <option>Draft</option>
                <option>Final</option>
              </select>
            </div>
        </div>
         <div>
          <label htmlFor="doc-tags" className="block text-sm font-medium text-gray-700">
            Tags <span className="text-gray-500 font-normal">(comma-separated)</span>
          </label>
          <input
            type="text"
            id="doc-tags"
            value={tags}
            onChange={(e) => setTags(e.target.value)}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm"
            placeholder="e.g., Pleading, Motion, Urgent"
          />
        </div>
        <div>
            <label className="block text-sm font-medium text-gray-700">
                File
            </label>
            <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                <div className="space-y-1 text-center">
                    <svg className="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
                        <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    <div className="flex text-sm text-gray-600">
                        <label htmlFor="file-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-brand-secondary hover:text-brand-secondary focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-brand-secondary">
                            <span>Upload a file</span>
                            <input id="file-upload" name="file-upload" type="file" className="sr-only" />
                        </label>
                        <p className="pl-1">or drag and drop</p>
                    </div>
                    <p className="text-xs text-gray-500">PNG, JPG, PDF, DOCX up to 10MB</p>
                </div>
            </div>
        </div>

        <div className="pt-4 flex justify-end space-x-3">
          <button
            type="button"
            onClick={handleClose}
            className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-secondary"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-brand-secondary hover:bg-opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-secondary"
          >
            Upload
          </button>
        </div>
      </form>
    </Modal>
  );
};

export default UploadModal;