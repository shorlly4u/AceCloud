
import React, { useState } from 'react';
import Modal from './Modal';
import { User } from '../types';

interface NewCaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreate: (caseData: { title: string; clientName: string; assignedLawyerId: string; }) => void;
  lawyers: User[];
}

const NewCaseModal: React.FC<NewCaseModalProps> = ({ isOpen, onClose, onCreate, lawyers }) => {
  const [title, setTitle] = useState('');
  const [clientName, setClientName] = useState('');
  const [assignedLawyerId, setAssignedLawyerId] = useState(lawyers[0]?.id || '');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !clientName.trim() || !assignedLawyerId) {
      setError('All fields are required.');
      return;
    }
    setError('');
    onCreate({ title, clientName, assignedLawyerId });
    // Reset form for next time
    setTitle('');
    setClientName('');
    setAssignedLawyerId(lawyers[0]?.id || '');
  };

  const handleClose = () => {
    // Reset form state on close
    setTitle('');
    setClientName('');
    setAssignedLawyerId(lawyers[0]?.id || '');
    setError('');
    onClose();
  }

  return (
    <Modal isOpen={isOpen} onClose={handleClose} title="Create New Case">
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && <p className="text-sm text-red-600 bg-red-100 p-3 rounded-md">{error}</p>}
        <div>
          <label htmlFor="case-title" className="block text-sm font-medium text-gray-700">
            Case Title
          </label>
          <input
            type="text"
            id="case-title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-brand-secondary focus:border-brand-secondary sm:text-sm"
            placeholder="e.g., Intellectual Property Dispute"
          />
        </div>
        <div>
          <label htmlFor="client-name" className="block text-sm font-medium text-gray-700">
            Client Name
          </label>
          <input
            type="text"
            id="client-name"
            value={clientName}
            onChange={(e) => setClientName(e.target.value)}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-brand-secondary focus:border-brand-secondary sm:text-sm"
            placeholder="e.g., Jane Doe"
          />
        </div>
        <div>
          <label htmlFor="lawyer-select" className="block text-sm font-medium text-gray-700">
            Assign Lawyer
          </label>
          <select
            id="lawyer-select"
            value={assignedLawyerId}
            onChange={(e) => setAssignedLawyerId(e.target.value)}
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-brand-secondary focus:border-brand-secondary sm:text-sm rounded-md"
          >
            {lawyers.map(lawyer => (
              <option key={lawyer.id} value={lawyer.id}>{lawyer.name}</option>
            ))}
          </select>
        </div>

        <div className="pt-4 flex justify-end space-x-3">
          <button
            type="button"
            onClick={handleClose}
            className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-secondary"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-brand-secondary hover:bg-opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-secondary"
          >
            Create Case
          </button>
        </div>
      </form>
    </Modal>
  );
};

export default NewCaseModal;