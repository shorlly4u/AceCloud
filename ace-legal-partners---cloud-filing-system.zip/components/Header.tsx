
import React, { useState, useEffect, useRef } from 'react';
import { User, Notification } from '../types';

interface HeaderProps {
  user: User;
  onLogout: () => void;
  notifications: Notification[];
  onMarkNotificationsRead: () => void;
}

const SearchIcon = () => (<svg className="w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>);
const BellIcon = () => (<svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6 6 0 10-12 0v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" /></svg>);
const LogoutIcon = () => (<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>);


const Header: React.FC<HeaderProps> = ({ user, onLogout, notifications, onMarkNotificationsRead }) => {
  const [isPanelOpen, setPanelOpen] = useState(false);
  const unreadCount = notifications.filter(n => !n.read).length;
  const panelRef = useRef<HTMLDivElement>(null);

  const handleTogglePanel = () => {
    const newPanelState = !isPanelOpen;
    setPanelOpen(newPanelState);
    if (newPanelState && unreadCount > 0) {
      // Use a small delay to allow the panel to open before marking as read
      setTimeout(() => onMarkNotificationsRead(), 500);
    }
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (panelRef.current && !panelRef.current.contains(event.target as Node)) {
        setPanelOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [panelRef]);

  return (
    <header className="flex items-center justify-between h-20 px-4 sm:px-6 lg:px-8 bg-white dark:bg-dark-bg-secondary border-b dark:border-dark-border">
      <div className="relative">
        <span className="absolute inset-y-0 left-0 flex items-center pl-3">
          <SearchIcon />
        </span>
        <input
          type="text"
          placeholder="Search for cases or documents..."
          className="w-full pl-10 pr-4 py-2 border rounded-md text-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-brand-secondary bg-transparent dark:border-dark-border dark:text-dark-text"
        />
      </div>
      <div className="flex items-center space-x-4">
        <div className="relative" ref={panelRef}>
            <button onClick={handleTogglePanel} className="relative text-brand-gray dark:text-dark-text-secondary hover:text-brand-secondary focus:outline-none">
              <BellIcon />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-xs font-bold text-white ring-2 ring-white">
                  {unreadCount}
                </span>
              )}
            </button>
            {isPanelOpen && (
              <div className="absolute right-0 mt-2 w-80 bg-white dark:bg-dark-bg-secondary rounded-md shadow-lg overflow-hidden z-20 border dark:border-dark-border">
                <div className="py-2 px-4 text-sm font-semibold text-brand-blue dark:text-dark-text border-b dark:border-dark-border">Notifications</div>
                <div className="divide-y dark:divide-dark-border max-h-96 overflow-y-auto">
                  {notifications.length > 0 ? notifications.map(n => (
                    <div key={n.id} className="p-3 text-sm text-gray-600 dark:text-dark-text-secondary hover:bg-gray-50 dark:hover:bg-dark-bg">
                      <p className="font-semibold text-brand-blue dark:text-dark-text">{n.message}</p>
                      <p className="text-xs text-gray-400 mt-1">{new Date(n.timestamp).toLocaleString()}</p>
                    </div>
                  )) : (
                     <p className="p-4 text-sm text-center text-gray-500 dark:text-dark-text-secondary">No new notifications.</p>
                  )}
                </div>
              </div>
            )}
        </div>

        <div className="flex items-center">
          <img className="w-10 h-10 rounded-full object-cover" src={user.avatarUrl} alt={user.name} />
          <div className="ml-3 text-right">
            <p className="text-sm font-semibold text-brand-blue dark:text-dark-text">{user.name}</p>
            <p className="text-xs text-brand-gray dark:text-dark-text-secondary">{user.role}</p>
          </div>
        </div>
         <button onClick={onLogout} title="Logout" className="p-2 text-brand-gray dark:text-dark-text-secondary hover:text-red-500 hover:bg-red-100 dark:hover:bg-red-500/20 rounded-full transition">
           <LogoutIcon />
        </button>
      </div>
    </header>
  );
};

export default Header;