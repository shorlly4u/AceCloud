
import React, { useState } from 'react';
import { Case, User, UserRole } from '../types';
import NewCaseModal from '../components/NewCaseModal';

interface DashboardProps {
  cases: Case[];
  onSelectCase: (caseData: Case) => void;
  userRole: UserRole;
  onCreateCase: (caseData: { title: string; clientName: string; assignedLawyerId: string; }) => void;
  lawyers: User[];
}

const CaseCard: React.FC<{ caseData: Case; onSelectCase: (caseData: Case) => void }> = ({ caseData, onSelectCase }) => (
  <div
    className="bg-white dark:bg-dark-bg-secondary rounded-lg shadow-md p-6 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 cursor-pointer flex flex-col justify-between dark:border dark:border-dark-border"
    onClick={() => onSelectCase(caseData)}
  >
    <div>
      <div className="flex justify-between items-start">
        <h3 className="text-lg font-bold text-brand-blue dark:text-dark-text">{caseData.title}</h3>
        <span className={`px-3 py-1 text-xs font-semibold rounded-full ${
          caseData.status === 'Active' ? 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300' :
          caseData.status === 'Closed' ? 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300' :
          'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300'
        }`}>
          {caseData.status}
        </span>
      </div>
      <p className="text-sm text-brand-gray dark:text-dark-text-secondary mt-1">Case #{caseData.caseNumber} - {caseData.caseType}</p>
    </div>
    <div className="mt-4 pt-4 border-t dark:border-dark-border">
      <p className="text-sm"><span className="font-semibold">Client:</span> {caseData.client.name}</p>
      <p className="text-sm"><span className="font-semibold">Assigned Lawyer:</span> {caseData.assignedLawyer.name}</p>
      <p className="text-sm mt-2"><span className="font-semibold">{caseData.documents.length}</span> Documents</p>
    </div>
  </div>
);

const Dashboard: React.FC<DashboardProps> = ({ cases, onSelectCase, userRole, onCreateCase, lawyers }) => {
  const [isNewCaseModalOpen, setNewCaseModalOpen] = useState(false);

  const handleCreateCase = (caseData: { title: string; clientName: string; assignedLawyerId: string; }) => {
    onCreateCase(caseData);
    setNewCaseModalOpen(false);
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-brand-blue dark:text-dark-text">
            {userRole === UserRole.Client ? "My Active Matters" : "Case Dashboard"}
        </h1>
        {[UserRole.Lawyer, UserRole.Secretary, UserRole.Admin].includes(userRole) && (
            <button 
              onClick={() => setNewCaseModalOpen(true)}
              className="px-4 py-2 bg-brand-secondary text-white rounded-md hover:bg-opacity-90 transition font-semibold">
                + New Case
            </button>
        )}
      </div>

      {cases.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {cases.map(caseData => (
            <CaseCard key={caseData.id} caseData={caseData} onSelectCase={onSelectCase} />
            ))}
        </div>
      ) : (
        <div className="text-center py-20 bg-white dark:bg-dark-bg-secondary rounded-lg shadow-md dark:border dark:border-dark-border">
            <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
            <h2 className="mt-2 text-xl font-semibold text-brand-blue dark:text-dark-text">
                {userRole === UserRole.Client ? "You have no active cases." : "No cases found"}
            </h2>
            <p className="mt-1 text-brand-gray dark:text-dark-text-secondary">
              {userRole === UserRole.Client 
                ? "Your lawyer will share case files with you here." 
                : "Get started by creating a new case."}
            </p>
        </div>
      )}

      <NewCaseModal
        isOpen={isNewCaseModalOpen}
        onClose={() => setNewCaseModalOpen(false)}
        onCreate={handleCreateCase}
        lawyers={lawyers}
      />
    </div>
  );
};

export default Dashboard;
