
import React, { useState, useMemo } from 'react';
import { Case, DocumentFile, UserRole, User, KeyDate, InternalNote } from '../types';
import { summarizeDocument } from '../services/geminiService';
import SummaryModal from '../components/SummaryModal';
import UploadModal from '../components/UploadModal';
import ShareModal, { ShareDetails } from '../components/ShareModal';

const FileIcon: React.FC<{ type: DocumentFile['type'] }> = ({ type }) => {
    const icons = {
        PDF: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v5.414a1 1 0 00.293.707L17.586 14H12a2 2 0 01-2-2V3z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 12h4m-4 4h4" /></svg>,
        Word: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>,
        Image: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>,
        Correspondence: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-yellow-500" viewBox="0 0 20 20" fill="currentColor"><path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" /><path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" /></svg>,
        Other: <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>,
    };
    return icons[type] || icons['Other'];
};

const LegalHoldIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 1.944A11.954 11.954 0 012.166 5.026a12.005 12.005 0 01-1.12 3.033A11.955 11.955 0 01.22 12.022c.343.344.695.683 1.058 1.018a11.958 11.958 0 011.12 3.033 11.954 11.954 0 016.602 3.088 11.954 11.954 0 016.602-3.088 11.958 11.958 0 011.12-3.033c.363-.335.715-.674 1.058-1.018a11.955 11.955 0 01-.826-3.961 12.005 12.005 0 01-1.12-3.033A11.954 11.954 0 0110 1.944zM9 13a1 1 0 112 0v2a1 1 0 11-2 0v-2zm0-8a1 1 0 011-1h.01a1 1 0 110 2H10a1 1 0 01-1-1z" clipRule="evenodd" /></svg>;
const ShieldIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 inline-block ml-2 text-blue-600" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 1.944A11.954 11.954 0 012.166 5.026a12.005 12.005 0 01-1.12 3.033A11.955 11.955 0 01.22 12.022c.343.344.695.683 1.058 1.018a11.958 11.958 0 011.12 3.033 11.954 11.954 0 016.602 3.088 11.954 11.954 0 016.602-3.088 11.958 11.958 0 011.12-3.033c.363-.335.715-.674 1.058-1.018a11.955 11.955 0 01-.826-3.961 12.005 12.005 0 01-1.12-3.033A11.954 11.954 0 0110 1.944zM8.22 8.22a.75.75 0 011.06 0L10 8.94l.72-.72a.75.75 0 111.06 1.06L11.06 10l.72.72a.75.75 0 11-1.06 1.06L10 11.06l-.72.72a.75.75 0 01-1.06-1.06L8.94 10l-.72-.72a.75.75 0 010-1.06z" clipRule="evenodd" /></svg>

const FileStatusBadge: React.FC<{status: DocumentFile['status']}> = ({ status }) => {
    const statusClasses = {
        Draft: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300',
        Final: 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300',
        Archived: 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300',
    };
    return <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${statusClasses[status]}`}>{status}</span>;
}

const FileItem: React.FC<{ file: DocumentFile; onSummarize: (file: DocumentFile) => void; onShare: (file: DocumentFile) => void; onDownload: (file: DocumentFile) => void; onUpdateStatus: (fileId: string, status: DocumentFile['status']) => void; userRole: UserRole }> = ({ file, onSummarize, onShare, onDownload, onUpdateStatus, userRole }) => {
    const canManage = [UserRole.Lawyer, UserRole.Admin, UserRole.Secretary].includes(userRole);

    return (
    <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-dark-bg-secondary rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700/50 transition">
        <div className="flex items-center space-x-4 flex-1 min-w-0">
            <FileIcon type={file.type} />
            <div className="min-w-0">
                <p className="font-semibold text-brand-blue dark:text-dark-text truncate">{file.name}</p>
                <div className="text-xs text-brand-gray dark:text-dark-text-secondary space-x-2">
                    <span>{file.size}</span>
                    <span>v{file.version}</span>
                    <span>by {file.uploadedBy}</span>
                    <FileStatusBadge status={file.status} />
                </div>
                 {file.tags && file.tags.length > 0 && (
                    <div className="mt-1 flex flex-wrap gap-1">
                        {file.tags.map(tag => (
                            <span key={tag} className="px-2 py-0.5 text-xs bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300 rounded-full">{tag}</span>
                        ))}
                    </div>
                )}
            </div>
        </div>
        <div className="flex items-center space-x-2 flex-shrink-0 ml-4">
            {canManage && (
                <>
                <select 
                    value={file.status}
                    onChange={(e) => onUpdateStatus(file.id, e.target.value as DocumentFile['status'])}
                    className="text-xs border-gray-300 dark:border-dark-border rounded-md shadow-sm focus:border-brand-secondary focus:ring focus:ring-brand-secondary focus:ring-opacity-50 bg-white dark:bg-dark-bg-secondary dark:text-dark-text"
                    onClick={e => e.stopPropagation()}
                >
                    <option value="Draft">Draft</option>
                    <option value="Final">Final</option>
                    <option value="Archived">Archived</option>
                </select>
                <button onClick={() => onSummarize(file)} title="Summarize with AI" className="p-2 text-purple-600 hover:bg-purple-100 dark:hover:bg-purple-500/20 rounded-full transition">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clipRule="evenodd" /></svg>
                </button>
                <button onClick={() => onShare(file)} title="Share Document" className="p-2 text-blue-600 hover:bg-blue-100 dark:hover:bg-blue-500/20 rounded-full transition">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M15 8a3 3 0 10-2.977-2.63l-4.94 2.47a3 3 0 100 4.319l4.94 2.47a3 3 0 10.895-1.789l-4.94-2.47a3.027 3.027 0 000-.74l4.94-2.47C13.456 7.68 14.19 8 15 8z" /></svg>
                </button>
                </>
            )}
             <button onClick={() => onDownload(file)} title="Download" className="p-2 text-brand-gray dark:text-dark-text-secondary hover:bg-gray-200 dark:hover:bg-gray-700 rounded-full transition">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
            </button>
        </div>
    </div>
)};

interface CaseDetailViewProps {
    caseData: Case;
    user: User;
    onBack: () => void;
    onDocumentUpload: (caseId: string, documentData: { name: string; type: DocumentFile['type']; tags: string[]; status: DocumentFile['status'] }) => void;
    addNotification: (message: string, caseId: string) => void;
    logAuditActivity: (caseId: string, action: string, details: string) => void;
    onToggleLegalHold: (caseId: string) => void;
    onUpdateDocumentStatus: (caseId: string, documentId: string, status: DocumentFile['status']) => void;
    onAddKeyDate: (caseId: string, keyDate: Omit<KeyDate, 'id'>) => void;
    onAddNote: (caseId: string, content: string) => void;
}

const CaseDetailView: React.FC<CaseDetailViewProps> = ({ caseData, user, onBack, onDocumentUpload, addNotification, logAuditActivity, onToggleLegalHold, onUpdateDocumentStatus, onAddKeyDate, onAddNote }) => {
    const [activeTab, setActiveTab] = useState<'documents' | 'audit' | 'dates' | 'internalNotes'>('documents');
    const [isSummaryModalOpen, setSummaryModalOpen] = useState(false);
    const [isUploadModalOpen, setUploadModalOpen] = useState(false);
    const [isShareModalOpen, setShareModalOpen] = useState(false);
    const [currentDocument, setCurrentDocument] = useState<DocumentFile | null>(null);
    const [documentToShare, setDocumentToShare] = useState<DocumentFile | null>(null);
    const [summary, setSummary] = useState<string | null>(null);
    const [isLoadingSummary, setIsLoadingSummary] = useState(false);
    const [summaryError, setSummaryError] = useState<string | null>(null);
    const [newKeyDate, setNewKeyDate] = useState({ date: '', description: '' });
    const [newNote, setNewNote] = useState('');
    
    const canManage = [UserRole.Lawyer, UserRole.Secretary, UserRole.Admin].includes(user.role);

    const documentGroups = useMemo(() => {
        const groups: { [key: string]: DocumentFile[] } = {};
        caseData.documents.forEach(doc => {
            if (!groups[doc.name]) {
                groups[doc.name] = [];
            }
            groups[doc.name].push(doc);
        });
        Object.values(groups).forEach(group => group.sort((a, b) => b.version - a.version));
        return Object.values(groups);
    }, [caseData.documents]);

    const handleSummarizeClick = async (file: DocumentFile) => {
        logAuditActivity(caseData.id, "AI Summarized", `${file.name} (v${file.version})`);
        setCurrentDocument(file);
        setSummaryModalOpen(true);
        setIsLoadingSummary(true);
        setSummary(null);
        setSummaryError(null);
        try {
            const result = await summarizeDocument(file.content);
            setSummary(result);
        } catch (error) {
            setSummaryError("Failed to generate summary.");
        } finally {
            setIsLoadingSummary(false);
        }
    };
    
    const handleUpload = (documentData: { name: string; type: DocumentFile['type']; tags: string[]; status: DocumentFile['status'] }) => {
        onDocumentUpload(caseData.id, documentData);
        setUploadModalOpen(false);
    };

    const handleShareClick = (file: DocumentFile) => {
        setDocumentToShare(file);
        setShareModalOpen(true);
    };

    const handleConfirmShare = (shareDetails: ShareDetails) => {
        if (documentToShare) {
            let notificationMessage = '';
            let auditDetails = '';
            if (shareDetails.method === 'link') {
                notificationMessage = `${user.name} shared "${documentToShare.name}" via link.`;
                auditDetails = `Shared "${documentToShare.name}" (v${documentToShare.version}) via expiring link (${shareDetails.expiration}). Password required: ${shareDetails.usePassword}.`;
            } else {
                notificationMessage = `${user.name} sent a PIN for "${documentToShare.name}".`;
                auditDetails = `Sent one-time PIN for "${documentToShare.name}" (v${documentToShare.version}) to ${shareDetails.email}.`;
            }
            addNotification(notificationMessage, caseData.id);
            logAuditActivity(caseData.id, "Shared", auditDetails);
        }
        setShareModalOpen(false);
        setDocumentToShare(null);
    };

    const handleDownloadClick = (file: DocumentFile) => {
        logAuditActivity(caseData.id, "Downloaded", `${file.name} (v${file.version})`);
        // In a real app, this would trigger a file download.
    };
    
    const handleAddKeyDateSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (newKeyDate.date && newKeyDate.description) {
            onAddKeyDate(caseData.id, newKeyDate);
            setNewKeyDate({ date: '', description: '' });
        }
    }
    
    const handleAddNoteSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (newNote.trim()) {
            onAddNote(caseData.id, newNote);
            setNewNote('');
        }
    };

    return (
        <div>
            <button onClick={onBack} className="flex items-center text-sm font-semibold text-brand-secondary hover:underline mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
                Back to Dashboard
            </button>

            <div className="bg-white dark:bg-dark-bg-secondary p-6 rounded-lg shadow-md mb-6 dark:border dark:border-dark-border">
                 <div className="flex justify-between items-start">
                    <div>
                        <h1 className="text-2xl font-bold text-brand-blue dark:text-dark-text flex items-center">
                            {caseData.title}
                            {caseData.legalHold && <span title="This case is under a legal hold"><ShieldIcon /></span>}
                        </h1>
                        <p className="text-md text-brand-gray dark:text-dark-text-secondary">Case #{caseData.caseNumber}</p>
                    </div>
                     {user.role === UserRole.Admin && (
                        <button 
                            onClick={() => onToggleLegalHold(caseData.id)}
                            className={`flex items-center px-4 py-2 rounded-md font-semibold text-sm transition ${caseData.legalHold ? 'bg-blue-600 text-white hover:bg-blue-700' : 'bg-gray-200 text-gray-800 hover:bg-gray-300 dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600'}`}
                        >
                            <LegalHoldIcon />
                            {caseData.legalHold ? 'Release Hold' : 'Place Legal Hold'}
                        </button>
                    )}
                </div>
                <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                    <div><span className="font-semibold">Client:</span> {caseData.client.name}</div>
                    <div><span className="font-semibold">Assigned Lawyer:</span> {caseData.assignedLawyer.name}</div>
                    <div><span className="font-semibold">Status:</span> {caseData.status}</div>
                </div>
            </div>

            <div className="bg-white dark:bg-dark-bg-secondary rounded-lg shadow-md dark:border dark:border-dark-border">
                <div className="border-b border-gray-200 dark:border-dark-border">
                    <nav className="-mb-px flex space-x-8 px-6" aria-label="Tabs">
                        <button onClick={() => setActiveTab('documents')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'documents' ? 'border-brand-secondary text-brand-secondary' : 'border-transparent text-gray-500 dark:text-dark-text-secondary hover:text-gray-700 dark:hover:text-dark-text hover:border-gray-300 dark:hover:border-dark-border'}`}>
                            Documents ({documentGroups.length})
                        </button>
                        {canManage && (
                            <>
                             <button onClick={() => setActiveTab('dates')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'dates' ? 'border-brand-secondary text-brand-secondary' : 'border-transparent text-gray-500 dark:text-dark-text-secondary hover:text-gray-700 dark:hover:text-dark-text hover:border-gray-300 dark:hover:border-dark-border'}`}>
                                Key Dates ({caseData.keyDates.length})
                            </button>
                            <button onClick={() => setActiveTab('internalNotes')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'internalNotes' ? 'border-brand-secondary text-brand-secondary' : 'border-transparent text-gray-500 dark:text-dark-text-secondary hover:text-gray-700 dark:hover:text-dark-text hover:border-gray-300 dark:hover:border-dark-border'}`}>
                                Internal Notes ({caseData.internalNotes.length})
                            </button>
                             <button onClick={() => setActiveTab('audit')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'audit' ? 'border-brand-secondary text-brand-secondary' : 'border-transparent text-gray-500 dark:text-dark-text-secondary hover:text-gray-700 dark:hover:text-dark-text hover:border-gray-300 dark:hover:border-dark-border'}`}>
                                Audit Log ({caseData.auditLogs.length})
                            </button>
                            </>
                        )}
                    </nav>
                </div>
                
                <div className="p-6">
                    {activeTab === 'documents' && (
                        <div>
                             <div className="flex justify-end mb-4">
                                {canManage && (
                                    <button onClick={() => setUploadModalOpen(true)} className="px-4 py-2 bg-brand-secondary text-white rounded-md hover:bg-opacity-90 transition font-semibold text-sm">
                                        + Upload Document
                                    </button>
                                )}
                            </div>
                            <div className="space-y-4">
                                {documentGroups.map(group => (
                                    <details key={group[0].id} className="bg-gray-50 dark:bg-dark-bg rounded-lg" open>
                                        <summary className="list-none focus:outline-none">
                                            <FileItem
                                                file={group[0]}
                                                onSummarize={handleSummarizeClick}
                                                onShare={handleShareClick}
                                                onDownload={handleDownloadClick}
                                                onUpdateStatus={(docId, status) => onUpdateDocumentStatus(caseData.id, docId, status)}
                                                userRole={user.role}
                                            />
                                        </summary>
                                        {group.length > 1 && (
                                            <div className="pl-12 pr-4 pb-2 mt-1 space-y-1">
                                                <p className="text-xs font-semibold text-gray-500 dark:text-dark-text-secondary">Version History:</p>
                                                {group.slice(1).map(version => (
                                                    <div key={version.id} className="flex items-center justify-between text-xs p-2 bg-white dark:bg-dark-bg-secondary rounded">
                                                        <span>v{version.version} - {version.uploadDate} by {version.uploadedBy}</span>
                                                        <button onClick={() => handleDownloadClick(version)} title="Download this version" className="p-1 text-brand-gray dark:text-dark-text-secondary hover:bg-gray-200 dark:hover:bg-gray-700 rounded-full transition">
                                                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                                                        </button>
                                                    </div>
                                                ))}
                                            </div>
                                        )}
                                    </details>
                                ))}
                            </div>
                        </div>
                    )}
                    {activeTab === 'audit' && (
                       <div className="overflow-x-auto">
                            <table className="min-w-full divide-y divide-gray-200 dark:divide-dark-border">
                                <thead className="bg-gray-50 dark:bg-dark-bg-secondary">
                                    <tr>
                                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-dark-text-secondary uppercase tracking-wider">User</th>
                                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-dark-text-secondary uppercase tracking-wider">Action</th>
                                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-dark-text-secondary uppercase tracking-wider">Details</th>
                                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-dark-text-secondary uppercase tracking-wider">Timestamp</th>
                                    </tr>
                                </thead>
                                <tbody className="bg-white dark:bg-dark-bg-secondary divide-y divide-gray-200 dark:divide-dark-border">
                                    {caseData.auditLogs.map(log => (
                                        <tr key={log.id}>
                                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-dark-text">{log.user}</td>
                                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-dark-text-secondary">{log.action}</td>
                                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-dark-text-secondary">{log.details}</td>
                                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-dark-text-secondary">{log.timestamp}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                     {activeTab === 'dates' && (
                       <div>
                            <form onSubmit={handleAddKeyDateSubmit} className="mb-6 p-4 bg-gray-50 dark:bg-dark-bg rounded-lg flex items-end gap-4">
                                <div className="flex-1">
                                    <label htmlFor="key-date-desc" className="block text-sm font-medium text-gray-700 dark:text-dark-text-secondary">Description</label>
                                    <input type="text" id="key-date-desc" value={newKeyDate.description} onChange={e => setNewKeyDate({...newKeyDate, description: e.target.value})} className="mt-1 block w-full px-3 py-2 border border-gray-300 dark:border-dark-border rounded-md shadow-sm bg-transparent" required />
                                </div>
                                <div className="flex-1">
                                    <label htmlFor="key-date" className="block text-sm font-medium text-gray-700 dark:text-dark-text-secondary">Date</label>
                                    <input type="date" id="key-date" value={newKeyDate.date} onChange={e => setNewKeyDate({...newKeyDate, date: e.target.value})} className="mt-1 block w-full px-3 py-2 border border-gray-300 dark:border-dark-border rounded-md shadow-sm bg-transparent" required />
                                </div>
                                <button type="submit" className="px-4 py-2 bg-brand-secondary text-white rounded-md hover:bg-opacity-90 transition font-semibold text-sm">Add Date</button>
                            </form>
                           <ul className="space-y-3">
                                {caseData.keyDates.map(kd => (
                                    <li key={kd.id} className="p-3 bg-white dark:bg-dark-bg border dark:border-dark-border rounded-md flex items-center justify-between">
                                        <p className="font-semibold text-brand-blue dark:text-dark-text">{kd.description}</p>
                                        <p className="text-sm text-gray-600 dark:text-dark-text-secondary font-mono bg-gray-100 dark:bg-dark-bg-secondary px-2 py-1 rounded">{new Date(kd.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric', timeZone: 'UTC' })}</p>
                                    </li>
                                ))}
                                {caseData.keyDates.length === 0 && <p className="text-center text-gray-500 dark:text-dark-text-secondary">No key dates have been set for this case.</p>}
                           </ul>
                        </div>
                    )}
                    {activeTab === 'internalNotes' && (
                       <div>
                            <form onSubmit={handleAddNoteSubmit} className="mb-6">
                                <label htmlFor="new-note" className="block text-sm font-medium text-gray-700 dark:text-dark-text-secondary mb-2">Add a new confidential note</label>
                                <textarea 
                                    id="new-note"
                                    rows={3}
                                    value={newNote}
                                    onChange={(e) => setNewNote(e.target.value)}
                                    className="w-full p-2 border border-gray-300 dark:border-dark-border rounded-md shadow-sm bg-transparent focus:ring-brand-secondary focus:border-brand-secondary"
                                    placeholder="Type your note here... visible only to internal staff."
                                ></textarea>
                                <div className="flex justify-end mt-2">
                                    <button type="submit" className="px-4 py-2 bg-brand-secondary text-white rounded-md hover:bg-opacity-90 transition font-semibold text-sm">
                                        Add Note
                                    </button>
                                </div>
                            </form>
                           <div className="space-y-4">
                                {caseData.internalNotes.map(note => (
                                    <div key={note.id} className="p-4 bg-gray-50 dark:bg-dark-bg border-l-4 border-brand-accent rounded-r-lg">
                                        <p className="text-gray-800 dark:text-dark-text whitespace-pre-wrap">{note.content}</p>
                                        <div className="text-right text-xs text-gray-500 dark:text-dark-text-secondary mt-2">
                                            - {note.author} on {new Date(note.timestamp).toLocaleString()}
                                        </div>
                                    </div>
                                ))}
                                {caseData.internalNotes.length === 0 && <p className="text-center text-gray-500 dark:text-dark-text-secondary">No internal notes have been added to this case yet.</p>}
                           </div>
                        </div>
                    )}
                </div>
            </div>

            {currentDocument && (
                <SummaryModal
                    isOpen={isSummaryModalOpen}
                    onClose={() => setSummaryModalOpen(false)}
                    summary={summary}
                    isLoading={isLoadingSummary}
                    error={summaryError}
                    documentName={currentDocument.name}
                />
            )}
            <UploadModal 
                isOpen={isUploadModalOpen}
                onClose={() => setUploadModalOpen(false)}
                onUpload={handleUpload}
            />
            {documentToShare && (
                <ShareModal
                    isOpen={isShareModalOpen}
                    onClose={() => setShareModalOpen(false)}
                    onShare={handleConfirmShare}
                    documentName={documentToShare.name}
                />
            )}
        </div>
    );
};

export default CaseDetailView;
