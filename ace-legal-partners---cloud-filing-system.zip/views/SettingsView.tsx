
import React, { useState } from 'react';
import { Settings, UserRole } from '../types';

interface SettingsViewProps {
    settings: Settings;
    onUpdateSettings: (newSettings: Partial<Settings>) => void;
    onNavigateToAdmin: () => void;
    userRole: UserRole;
}

const SettingsCard: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <div className="bg-white dark:bg-dark-bg-secondary p-6 rounded-lg shadow-md dark:border dark:border-dark-border">
        <h2 className="text-xl font-semibold text-brand-blue dark:text-dark-text mb-4 border-b dark:border-dark-border pb-3">{title}</h2>
        <div className="space-y-4">
            {children}
        </div>
    </div>
);

const Toggle: React.FC<{ enabled: boolean; onChange: (enabled: boolean) => void; label: string }> = ({ enabled, onChange, label }) => (
    <div className="flex items-center justify-between">
        <span className="font-medium text-gray-700 dark:text-dark-text-secondary">{label}</span>
        <button
            type="button"
            className={`${
                enabled ? 'bg-brand-secondary' : 'bg-gray-200 dark:bg-gray-600'
            } relative inline-flex items-center h-6 rounded-full w-11 transition-colors`}
            onClick={() => onChange(!enabled)}
        >
            <span className={`${
                enabled ? 'translate-x-6' : 'translate-x-1'
            } inline-block w-4 h-4 transform bg-white rounded-full transition-transform`} />
        </button>
    </div>
);

const SettingsView: React.FC<SettingsViewProps> = ({ settings, onUpdateSettings, onNavigateToAdmin, userRole }) => {
    const [localSettings, setLocalSettings] = useState(settings);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setLocalSettings(prev => ({ ...prev, [name]: value }));
    };

    // FIX: Changed 'value' type to 'any' to allow this handler to be used for both boolean and string-based settings.
    const handleToggleChange = (name: keyof Settings, value: any) => {
        setLocalSettings(prev => ({ ...prev, [name]: value }));
    };

    const handleSave = (section: keyof Settings | (keyof Settings)[]) => {
        const fieldsToUpdate: Partial<Settings> = {};
        if (Array.isArray(section)) {
            section.forEach(key => {
                // FIX: Cast to 'any' to work around a TypeScript limitation with assigning to properties using a union-type key.
                (fieldsToUpdate as any)[key] = localSettings[key];
            });
        } else {
            // FIX: Cast to 'any' to work around a TypeScript limitation with assigning to properties using a union-type key.
            (fieldsToUpdate as any)[section] = localSettings[section];
        }
        onUpdateSettings(fieldsToUpdate);
        alert(`${Array.isArray(section) ? section.join(' & ') : section} settings saved!`);
    };

    return (
        <div>
            <h1 className="text-3xl font-bold text-brand-blue dark:text-dark-text mb-6">Settings</h1>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Left column for navigation/menu */}
                <div className="lg:col-span-1">
                    <div className="bg-white dark:bg-dark-bg-secondary p-4 rounded-lg shadow-md dark:border dark:border-dark-border">
                        <ul className="space-y-2">
                           <li><a href="#appearance" className="block p-3 rounded-md hover:bg-gray-100 dark:hover:bg-dark-bg font-medium">Appearance & Customization</a></li>
                           <li><a href="#general" className="block p-3 rounded-md hover:bg-gray-100 dark:hover:bg-dark-bg font-medium">General Settings</a></li>
                           <li><a href="#storage" className="block p-3 rounded-md hover:bg-gray-100 dark:hover:bg-dark-bg font-medium">Storage & File Controls</a></li>
                           <li><a href="#security" className="block p-3 rounded-md hover:bg-gray-100 dark:hover:bg-dark-bg font-medium">Security & Compliance</a></li>
                           {userRole === UserRole.Admin && (
                               <li><button onClick={onNavigateToAdmin} className="w-full text-left p-3 rounded-md hover:bg-gray-100 dark:hover:bg-dark-bg font-medium text-brand-secondary">User & Role Management</button></li>
                           )}
                        </ul>
                    </div>
                </div>

                {/* Right column for content */}
                <div className="lg:col-span-2 space-y-8">
                    <div id="appearance">
                        <SettingsCard title="Appearance & Customization">
                            <Toggle
                                label="Dark Mode"
                                enabled={localSettings.theme === 'dark'}
                                onChange={(enabled) => handleToggleChange('theme', enabled ? 'dark' : 'light')}
                            />
                             <div className="flex justify-end pt-4">
                                <button onClick={() => handleSave('theme')} className="px-4 py-2 bg-brand-secondary text-white rounded-md hover:bg-opacity-90 transition font-semibold text-sm">Save Appearance</button>
                            </div>
                        </SettingsCard>
                    </div>

                    <div id="general">
                         <SettingsCard title="General Settings">
                            <div>
                                <label htmlFor="firmName" className="block text-sm font-medium text-gray-700 dark:text-dark-text-secondary">Firm Name</label>
                                <input type="text" name="firmName" id="firmName" value={localSettings.firmName} onChange={handleInputChange} className="mt-1 block w-full px-3 py-2 border border-gray-300 dark:border-dark-border rounded-md shadow-sm bg-transparent" />
                            </div>
                             <div>
                                <label htmlFor="firmAddress" className="block text-sm font-medium text-gray-700 dark:text-dark-text-secondary">Firm Address</label>
                                <textarea name="firmAddress" id="firmAddress" rows={3} value={localSettings.firmAddress} onChange={handleInputChange} className="mt-1 block w-full px-3 py-2 border border-gray-300 dark:border-dark-border rounded-md shadow-sm bg-transparent" />
                            </div>
                             <div className="flex justify-end pt-4">
                                <button onClick={() => handleSave(['firmName', 'firmAddress'])} className="px-4 py-2 bg-brand-secondary text-white rounded-md hover:bg-opacity-90 transition font-semibold text-sm">Save General Info</button>
                            </div>
                        </SettingsCard>
                    </div>

                     <div id="storage">
                        <SettingsCard title="Storage & File Controls">
                            <div>
                                <label htmlFor="retentionPeriod" className="block text-sm font-medium text-gray-700 dark:text-dark-text-secondary">Data Retention Policy</label>
                                <select name="retentionPeriod" id="retentionPeriod" value={localSettings.retentionPeriod} onChange={handleInputChange} className="mt-1 block w-full p-2 border border-gray-300 dark:border-dark-border rounded-md bg-transparent">
                                    <option value="1">1 Year</option>
                                    <option value="3">3 Years</option>
                                    <option value="7">7 Years</option>
                                    <option value="10">10 Years</option>
                                </select>
                            </div>
                            <Toggle
                                label="Enable Document Versioning"
                                enabled={localSettings.versioning}
                                onChange={(enabled) => handleToggleChange('versioning', enabled)}
                            />
                             <div className="flex justify-end pt-4">
                                <button onClick={() => handleSave(['retentionPeriod', 'versioning'])} className="px-4 py-2 bg-brand-secondary text-white rounded-md hover:bg-opacity-90 transition font-semibold text-sm">Save Storage Policy</button>
                            </div>
                        </SettingsCard>
                    </div>

                     <div id="security">
                        <SettingsCard title="Security & Compliance">
                             <div>
                                <label htmlFor="ipWhitelist" className="block text-sm font-medium text-gray-700 dark:text-dark-text-secondary">IP Whitelist</label>
                                <p className="text-xs text-gray-500 mb-1">Enter one IP address per line. Only these IPs will be able to access the system.</p>
                                <textarea name="ipWhitelist" id="ipWhitelist" rows={4} value={localSettings.ipWhitelist} onChange={handleInputChange} className="mt-1 block w-full px-3 py-2 border border-gray-300 dark:border-dark-border rounded-md shadow-sm bg-transparent font-mono text-sm" />
                            </div>
                             <div className="flex justify-between items-center pt-4">
                                 <button onClick={() => alert('Exporting compliance report...')} className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-opacity-90 transition font-semibold text-sm">
                                    Export Compliance Report
                                </button>
                                <button onClick={() => handleSave('ipWhitelist')} className="px-4 py-2 bg-brand-secondary text-white rounded-md hover:bg-opacity-90 transition font-semibold text-sm">Save Security Settings</button>
                            </div>
                        </SettingsCard>
                    </div>

                </div>
            </div>
        </div>
    );
};

export default SettingsView;
