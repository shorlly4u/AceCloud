
import React, { useState } from 'react';
import { User, UserRole } from '../types';

interface SignUpViewProps {
  onSignUp: (newUser: Omit<User, 'id' | 'avatarUrl' | 'status'>) => boolean;
  onNavigateToLogin: () => void;
}

const CloudLegalLogo: React.FC<{ className?: string }> = ({ className }) => (
    <svg
        viewBox="0 0 100 80"
        className={className}
        xmlns="http://www.w3.org/2000/svg"
    >
        <g stroke="currentColor" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" fill="none">
            <path d="M 65,15 C 60,2.5 40,2.5 35,15 C 20,15 15,30 25,40 L 75,40 C 85,30 80,15 65,15 Z" />
            <g transform="translate(0, 5)">
                <path d="M 50,40 L 50,65" />
                <path d="M 30,40 L 70,40" />
                <path d="M 35,45 L 35,40" />
                <path d="M 65,45 L 65,40" />
                <path d="M 25,55 C 25,60 45,60 45,55" />
                <path d="M 55,55 C 55,60 75,60 75,55" />
            </g>
        </g>
    </svg>
);


const SignUpView: React.FC<SignUpViewProps> = ({ onSignUp, onNavigateToLogin }) => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [role, setRole] = useState<UserRole>(UserRole.Client);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState(false);

    const validatePassword = (pass: string) => {
        // Min 10 chars, upper/lowercase, number, symbol
        const re = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{10,}$/;
        return re.test(pass);
    }

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');

        if (!name || !email || !password || !confirmPassword) {
            setError('All fields are required.');
            return;
        }

        const staffRoles = [UserRole.Lawyer, UserRole.Admin, UserRole.Secretary];
        if (staffRoles.includes(role) && !email.endsWith('@acelegal.sl')) {
            setError('Staff members (Lawyer, Secretary) must use an @acelegal.sl email address.');
            return;
        }

        if (!validatePassword(password)) {
            setError('Password does not meet the policy: Minimum 10 characters, including at least one uppercase letter, one lowercase letter, one number, and one symbol.');
            return;
        }

        if (password !== confirmPassword) {
            setError('Passwords do not match.');
            return;
        }

        const signupSuccess = onSignUp({ name, email, password, role });

        if (signupSuccess) {
            setSuccess(true);
        } else {
            setError('An account with this email address already exists.');
        }
    };

    if (success) {
        return (
            <div className="min-h-screen bg-brand-blue flex flex-col justify-center items-center p-4">
                <div className="w-full max-w-md bg-white rounded-lg shadow-2xl p-8 text-center">
                    <h2 className="text-2xl font-bold text-green-600 mb-4">Registration Successful!</h2>
                    <p className="text-brand-gray mb-6">Your account has been created and is now pending approval from an administrator. You will be notified via email once your account is activated.</p>
                    <button
                        onClick={onNavigateToLogin}
                        className="w-full bg-brand-secondary text-white font-bold py-3 px-4 rounded-md hover:bg-opacity-90"
                    >
                        Return to Login
                    </button>
                </div>
            </div>
        )
    }

    return (
        <div className="min-h-screen bg-brand-blue flex flex-col justify-center items-center p-4">
           <div className="flex flex-col items-center justify-center mb-6 text-white">
                <CloudLegalLogo className="w-24 h-24 text-brand-accent" />
                <h1 className="text-3xl font-bold mt-4">Ace Legal Partners</h1>
            </div>
            <div className="w-full max-w-md bg-white rounded-lg shadow-2xl p-8">
                <h2 className="text-2xl font-bold text-center text-brand-blue mb-6">Create an Account</h2>
                
                {error && (
                    <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-md mb-4 text-sm" role="alert">
                        <span className="block sm:inline">{error}</span>
                    </div>
                )}
                
                <form onSubmit={handleSubmit} className="space-y-4">
                     <div>
                        <label htmlFor="name" className="text-sm font-bold text-gray-600 block">Full Name</label>
                        <input id="name" type="text" value={name} onChange={(e) => setName(e.target.value)} required className="w-full p-3 mt-1 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-secondary" />
                    </div>
                    <div>
                        <label htmlFor="email" className="text-sm font-bold text-gray-600 block">Email Address</label>
                        <input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="w-full p-3 mt-1 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-secondary" />
                    </div>
                    <div>
                        <label htmlFor="role" className="text-sm font-bold text-gray-600 block">I am a...</label>
                        <select id="role" value={role} onChange={e => setRole(e.target.value as UserRole)} className="w-full p-3 mt-1 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-secondary bg-white">
                            <option value={UserRole.Client}>Client</option>
                            <option value={UserRole.Lawyer}>Lawyer</option>
                            <option value={UserRole.Secretary}>Secretary</option>
                        </select>
                    </div>
                    <div>
                        <label htmlFor="password" className="text-sm font-bold text-gray-600 block">Password</label>
                        <input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required className="w-full p-3 mt-1 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-secondary" />
                        <p className="text-xs text-gray-400 mt-1">Min. 10 chars, upper/lowercase, number, symbol.</p>
                    </div>
                    <div>
                        <label htmlFor="confirmPassword" className="text-sm font-bold text-gray-600 block">Confirm Password</label>
                        <input id="confirmPassword" type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required className="w-full p-3 mt-1 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-secondary" />
                    </div>
                    <div>
                        <button type="submit" className="w-full bg-brand-secondary text-white font-bold py-3 px-4 rounded-md hover:bg-opacity-90">
                            Sign Up
                        </button>
                    </div>
                </form>

                <div className="text-center mt-6">
                    <p className="text-sm text-gray-600">
                        Already have an account?{' '}
                        <button type="button" onClick={onNavigateToLogin} className="font-medium text-brand-secondary hover:underline">
                            Sign in
                        </button>
                    </p>
                </div>
            </div>
            <p className="text-center text-sm text-gray-400 mt-8">&copy; 2024 Ace Legal Partners. All Rights Reserved.</p>
        </div>
    );
};

export default SignUpView;
