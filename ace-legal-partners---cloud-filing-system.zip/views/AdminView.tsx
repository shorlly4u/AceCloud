
import React, { useState, useMemo } from 'react';
import { User, AuditLog, UserRole, Case } from '../types';
import InviteUserModal from '../components/InviteUserModal';

const StatCard: React.FC<{ title: string; value: string | number; icon: React.ReactNode }> = ({ title, value, icon }) => (
    <div className="bg-white dark:bg-dark-bg-secondary p-6 rounded-lg shadow flex items-center dark:border dark:border-dark-border">
        <div className="bg-brand-secondary text-white rounded-full p-3 mr-4">
            {icon}
        </div>
        <div>
            <p className="text-sm font-medium text-gray-500 dark:text-dark-text-secondary">{title}</p>
            <p className="text-2xl font-bold text-brand-blue dark:text-dark-text">{value}</p>
        </div>
    </div>
);

const StorageIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4M4 7s0 0 0 0m16 0s0 0 0 0M12 11a4 4 0 100-8 4 4 0 000 8z" /></svg>;
const UsersIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M15 21a6 6 0 00-9-5.197m0 0A5.995 5.995 0 0012 12a5.995 5.995 0 00-3-5.197m12 0a4 4 0 110 5.292" /></svg>;

interface AdminViewProps {
    users: User[];
    systemLogs: AuditLog[];
    onUpdateUser: (userId: string, updates: Partial<Pick<User, 'role' | 'status'>>) => void;
    onInviteUser: (email: string, role: UserRole) => void;
    cases: Case[];
}

const AdminView: React.FC<AdminViewProps> = ({ users, systemLogs, onUpdateUser, onInviteUser, cases }) => {
    const [activeTab, setActiveTab] = useState<'users' | 'logs' | 'billing' | 'data'>('users');
    const [isInviteModalOpen, setInviteModalOpen] = useState(false);
    const [logFilter, setLogFilter] = useState<'All' | AuditLog['category']>('All');

    const handleInvite = (email: string, role: UserRole) => {
        onInviteUser(email, role);
        setInviteModalOpen(false);
    };

    const filteredLogs = useMemo(() => {
        if (logFilter === 'All') return systemLogs;
        return systemLogs.filter(log => log.category === logFilter);
    }, [systemLogs, logFilter]);
    
    const totalStorage = useMemo(() => {
        const totalMB = cases.reduce((total, currentCase) => {
            const caseTotal = currentCase.documents.reduce((docTotal, doc) => {
                const size = parseFloat(doc.size);
                return isNaN(size) ? docTotal : docTotal + size;
            }, 0);
            return total + caseTotal;
        }, 0);
        return `${totalMB.toFixed(2)} MB`;
    }, [cases]);

    const activeUsers = useMemo(() => users.filter(u => u.status === 'Active').length, [users]);
    const casesOnLegalHold = useMemo(() => cases.filter(c => c.legalHold), [cases]);

    return (
        <div>
            <h1 className="text-3xl font-bold text-brand-blue dark:text-dark-text mb-6">Admin Console</h1>

            <div className="bg-white dark:bg-dark-bg-secondary rounded-lg shadow-md dark:border dark:border-dark-border">
                <div className="border-b border-gray-200 dark:border-dark-border">
                    <nav className="-mb-px flex space-x-8 px-6" aria-label="Tabs">
                        <button onClick={() => setActiveTab('users')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'users' ? 'border-brand-secondary text-brand-secondary' : 'border-transparent text-gray-500 dark:text-dark-text-secondary hover:text-gray-700 dark:hover:text-dark-text hover:border-gray-300 dark:hover:border-dark-border'}`}>
                            User Management
                        </button>
                         <button onClick={() => setActiveTab('logs')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'logs' ? 'border-brand-secondary text-brand-secondary' : 'border-transparent text-gray-500 dark:text-dark-text-secondary hover:text-gray-700 dark:hover:text-dark-text hover:border-gray-300 dark:hover:border-dark-border'}`}>
                            System Logs
                        </button>
                        <button onClick={() => setActiveTab('billing')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'billing' ? 'border-brand-secondary text-brand-secondary' : 'border-transparent text-gray-500 dark:text-dark-text-secondary hover:text-gray-700 dark:hover:text-dark-text hover:border-gray-300 dark:hover:border-dark-border'}`}>
                            Billing & Usage
                        </button>
                        <button onClick={() => setActiveTab('data')} className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'data' ? 'border-brand-secondary text-brand-secondary' : 'border-transparent text-gray-500 dark:text-dark-text-secondary hover:text-gray-700 dark:hover:text-dark-text hover:border-gray-300 dark:hover:border-dark-border'}`}>
                            Data Management
                        </button>
                    </nav>
                </div>
                
                <div className="p-6">
                    {activeTab === 'users' && (
                        <div>
                            <div className="flex justify-end mb-4">
                                <button onClick={() => setInviteModalOpen(true)} className="px-4 py-2 bg-brand-secondary text-white rounded-md hover:bg-opacity-90 transition font-semibold text-sm">
                                    + Invite User
                                </button>
                            </div>
                            <div className="overflow-x-auto">
                                <table className="min-w-full divide-y divide-gray-200 dark:divide-dark-border">
                                    <thead className="bg-gray-50 dark:bg-dark-bg">
                                        <tr>
                                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-dark-text-secondary uppercase tracking-wider">Name</th>
                                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-dark-text-secondary uppercase tracking-wider">Email</th>
                                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-dark-text-secondary uppercase tracking-wider">Role</th>
                                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-dark-text-secondary uppercase tracking-wider">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody className="bg-white dark:bg-dark-bg-secondary divide-y divide-gray-200 dark:divide-dark-border">
                                        {users.map(user => (
                                            <tr key={user.id} className={
                                                user.status === 'Invited' ? 'bg-yellow-50 dark:bg-yellow-900/20' : 
                                                user.status === 'Inactive' ? 'bg-gray-100 dark:bg-gray-800/20 opacity-60' : ''
                                            }>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-dark-text">{user.name}</td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-dark-text-secondary">{user.email}</td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-dark-text-secondary">
                                                     <select 
                                                        value={user.role} 
                                                        onChange={(e) => onUpdateUser(user.id, { role: e.target.value as UserRole })}
                                                        className="p-1 border rounded-md bg-transparent dark:border-dark-border"
                                                    >
                                                        <option value={UserRole.Client}>Client</option>
                                                        <option value={UserRole.Lawyer}>Lawyer</option>
                                                        <option value={UserRole.Admin}>Admin</option>
                                                    </select>
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-dark-text-secondary">
                                                     <select 
                                                        value={user.status}
                                                        onChange={(e) => onUpdateUser(user.id, { status: e.target.value as User['status'] })}
                                                        className="p-1 border rounded-md bg-transparent dark:border-dark-border"
                                                    >
                                                        <option value="Active">Active</option>
                                                        <option value="Inactive">Inactive</option>
                                                        <option value="Invited">Invited</option>
                                                    </select>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    )}
                     {activeTab === 'logs' && (
                       <div>
                            <div className="flex justify-between items-center mb-4">
                                <div className="flex items-center space-x-2">
                                    <label htmlFor="log-filter" className="text-sm font-medium">Filter by category:</label>
                                    <select 
                                        id="log-filter"
                                        value={logFilter}
                                        onChange={e => setLogFilter(e.target.value as any)}
                                        className="p-1 border rounded-md text-sm bg-transparent dark:border-dark-border"
                                    >
                                        <option value="All">All</option>
                                        <option value="User Action">User Action</option>
                                        <option value="Security">Security</option>
                                        <option value="System">System</option>
                                    </select>
                                </div>
                                <button onClick={() => alert('Simulating log export...')} className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-opacity-90 transition font-semibold text-sm">
                                    Export Logs
                                </button>
                            </div>
                            <div className="overflow-x-auto">
                                <table className="min-w-full divide-y divide-gray-200 dark:divide-dark-border">
                                    <thead className="bg-gray-50 dark:bg-dark-bg">
                                        <tr>
                                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-dark-text-secondary uppercase tracking-wider">User</th>
                                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-dark-text-secondary uppercase tracking-wider">Action</th>
                                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-dark-text-secondary uppercase tracking-wider">Details</th>
                                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-dark-text-secondary uppercase tracking-wider">Timestamp</th>
                                        </tr>
                                    </thead>
                                    <tbody className="bg-white dark:bg-dark-bg-secondary divide-y divide-gray-200 dark:divide-dark-border">
                                        {filteredLogs.map(log => (
                                            <tr key={log.id} className={log.category === 'Security' ? 'bg-yellow-50 dark:bg-yellow-900/20' : ''}>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-dark-text">{log.user}</td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-dark-text-secondary">{log.action}</td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-dark-text-secondary">{log.details}</td>
                                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-dark-text-secondary">{log.timestamp}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    )}
                    {activeTab === 'billing' && (
                        <div className="space-y-6">
                             <h2 className="text-xl font-semibold text-brand-blue dark:text-dark-text">Usage Overview</h2>
                             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <StatCard title="Total Storage Used" value={totalStorage} icon={<StorageIcon />} />
                                <StatCard title="Active Users" value={activeUsers} icon={<UsersIcon />} />
                             </div>
                             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="bg-white dark:bg-dark-bg p-6 rounded-lg shadow dark:border dark:border-dark-border">
                                    <h3 className="text-lg font-semibold text-brand-blue dark:text-dark-text mb-4">Billing Summary</h3>
                                    <div className="space-y-2 text-sm">
                                        <div className="flex justify-between"><span className="text-gray-500 dark:text-dark-text-secondary">Current Plan:</span><span className="font-semibold">Business Tier</span></div>
                                        <div className="flex justify-between"><span className="text-gray-500 dark:text-dark-text-secondary">Next Billing Date:</span><span className="font-semibold">01/12/2024</span></div>
                                        <div className="flex justify-between border-t dark:border-dark-border pt-2 mt-2"><span className="text-gray-500 dark:text-dark-text-secondary">Estimated Monthly Cost:</span><span className="font-bold text-green-600">$499.00</span></div>
                                    </div>
                                </div>
                                <div className="bg-white dark:bg-dark-bg p-6 rounded-lg shadow dark:border dark:border-dark-border">
                                    <h3 className="text-lg font-semibold text-brand-blue dark:text-dark-text mb-4">Storage by Case</h3>
                                    <div className="space-y-2 text-sm">
                                        {cases.slice(0, 5).map(c => (
                                            <div key={c.id} className="flex justify-between items-center">
                                                <span>{c.title}</span>
                                                <span className="font-mono text-xs p-1 bg-gray-100 dark:bg-dark-bg-secondary rounded">
                                                    {c.documents.reduce((acc, doc) => acc + parseFloat(doc.size), 0).toFixed(2)} MB
                                                </span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                             </div>
                        </div>
                    )}
                     {activeTab === 'data' && (
                        <div className="space-y-6">
                             <div className="bg-white dark:bg-dark-bg p-6 rounded-lg shadow dark:border dark:border-dark-border">
                                <h3 className="text-lg font-semibold text-brand-blue dark:text-dark-text mb-4">Data Retention Policy</h3>
                                <div className="flex items-center space-x-4">
                                    <label htmlFor="retention-period" className="text-sm font-medium">Retain documents for:</label>
                                    <select id="retention-period" className="p-2 border rounded-md bg-transparent dark:border-dark-border">
                                        <option>1 Year</option>
                                        <option>3 Years</option>
                                        <option selected>7 Years (Default)</option>
                                        <option>10 Years</option>
                                        <option>Indefinitely</option>
                                    </select>
                                    <button className="px-4 py-2 bg-brand-secondary text-white rounded-md hover:bg-opacity-90 transition font-semibold text-sm">
                                        Save Policy
                                    </button>
                                </div>
                                <p className="text-xs text-gray-500 dark:text-dark-text-secondary mt-2">This policy applies to documents in closed cases not under a legal hold.</p>
                             </div>
                              <div className="bg-white dark:bg-dark-bg p-6 rounded-lg shadow dark:border dark:border-dark-border">
                                <h3 className="text-lg font-semibold text-brand-blue dark:text-dark-text mb-4">Cases on Legal Hold ({casesOnLegalHold.length})</h3>
                                {casesOnLegalHold.length > 0 ? (
                                    <ul className="divide-y dark:divide-dark-border">
                                        {casesOnLegalHold.map(c => (
                                            <li key={c.id} className="py-2 flex justify-between items-center text-sm">
                                                <span>{c.title} ({c.caseNumber})</span>
                                                <span className="text-gray-500 dark:text-dark-text-secondary">Placed by: Aisha Jalloh</span>
                                            </li>
                                        ))}
                                    </ul>
                                ) : (
                                    <p className="text-sm text-gray-500 dark:text-dark-text-secondary">No cases are currently under a legal hold.</p>
                                )}
                             </div>
                        </div>
                    )}
                </div>
            </div>
            <InviteUserModal 
                isOpen={isInviteModalOpen}
                onClose={() => setInviteModalOpen(false)}
                onInvite={handleInvite}
            />
        </div>
    );
};

export default AdminView;
