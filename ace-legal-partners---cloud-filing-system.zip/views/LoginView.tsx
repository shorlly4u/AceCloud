
import React, { useState, useRef } from 'react';
import { User } from '../types';

interface LoginViewProps {
  onLogin: (email: string, password?: string) => void;
  onSsoLogin: (provider: 'Google' | 'Microsoft') => void;
  error: string;
  onNavigateToSignUp: () => void;
}

const CloudLegalLogo: React.FC<{ className?: string }> = ({ className }) => (
    <svg
        viewBox="0 0 100 80"
        className={className}
        xmlns="http://www.w3.org/2000/svg"
    >
        <g stroke="currentColor" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" fill="none">
            {/* Cloud Outline */}
            <path d="M 65,15 C 60,2.5 40,2.5 35,15 C 20,15 15,30 25,40 L 75,40 C 85,30 80,15 65,15 Z" />
            {/* Scales of Justice inside the cloud */}
            <g transform="translate(0, 5)">
                <path d="M 50,40 L 50,65" />
                <path d="M 30,40 L 70,40" />
                <path d="M 35,45 L 35,40" />
                <path d="M 65,45 L 65,40" />
                <path d="M 25,55 C 25,60 45,60 45,55" />
                <path d="M 55,55 C 55,60 75,60 75,55" />
            </g>
        </g>
    </svg>
);


const GoogleIcon = () => <svg viewBox="0 0 24 24" className="w-5 h-5"><path fill="currentColor" d="M21.35,11.1H12.18V13.83H18.69C18.36,17.64 15.19,19.27 12.19,19.27C8.36,19.27 5,16.25 5,12C5,7.9 8.2,4.73 12.19,4.73C15.29,4.73 17.1,6.7 17.1,6.7L19,4.72C19,4.72 16.56,2 12.19,2C6.42,2 2.03,6.8 2.03,12C2.03,17.05 6.16,22 12.19,22C17.6,22 21.5,18.33 21.5,12.33C21.5,11.76 21.45,11.43 21.35,11.1V11.1Z" /></svg>;
const MicrosoftIcon = () => <svg viewBox="0 0 24 24" className="w-5 h-5"><path fill="currentColor" d="M11.5,22.5H2V13H11.5V22.5M22,11.5V2H12.5V11.5H22M11.5,11.5H2V2H11.5V11.5M22,22.5H12.5V13H22V22.5Z" /></svg>;

const LoginView: React.FC<LoginViewProps> = ({ onLogin, onSsoLogin, error, onNavigateToSignUp }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const passwordInputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(email, password);
  };

  const handleAdminLoginClick = (e: React.MouseEvent) => {
    e.preventDefault();
    setEmail('admin@acelegalpartnerssl.com');
    passwordInputRef.current?.focus();
  };

  return (
    <div className="min-h-screen bg-brand-blue flex flex-col justify-center items-center p-4">
       <div className="flex flex-col items-center justify-center mb-6 text-white">
        <CloudLegalLogo className="w-24 h-24 text-brand-accent" />
        <h1 className="text-3xl font-bold mt-4">Ace Legal Partners</h1>
      </div>
      <div className="w-full max-w-md bg-white rounded-lg shadow-2xl p-8">
        <h2 className="text-2xl font-bold text-center text-brand-blue mb-2">Cloud Filing System</h2>
        <p className="text-center text-brand-gray mb-6">Please sign in to continue.</p>
        
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-md mb-4" role="alert">
            <span className="block sm:inline">{error}</span>
          </div>
        )}
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="email" className="text-sm font-bold text-gray-600 block">Email Address</label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full p-3 mt-1 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-secondary"
              placeholder="e.g., your.email@example.com"
            />
          </div>
          <div>
            <div className="flex justify-between items-baseline">
              <label htmlFor="password" className="text-sm font-bold text-gray-600 block">Password</label>
              <button type="button" onClick={() => alert('A password reset link has been sent to your verified company email.')} className="text-sm text-brand-secondary hover:underline">Forgot password?</button>
            </div>
            <input
              id="password"
              type="password"
              ref={passwordInputRef}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="w-full p-3 mt-1 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-secondary"
              placeholder="••••••••"
            />
            <p className="text-xs text-gray-400 mt-2">
                Policy: Min. 10 chars, upper/lowercase, number, symbol.
            </p>
          </div>
          <div>
            <button
              type="submit"
              className="w-full bg-brand-secondary text-white font-bold py-3 px-4 rounded-md hover:bg-opacity-90 transition-transform transform hover:scale-105"
            >
              Sign In
            </button>
          </div>
        </form>

        <div className="my-6 flex items-center">
            <div className="flex-grow border-t border-gray-300"></div>
            <span className="flex-shrink mx-4 text-sm text-gray-400">Or sign in with</span>
            <div className="flex-grow border-t border-gray-300"></div>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4">
            <button onClick={() => onSsoLogin('Google')} className="flex-1 flex items-center justify-center py-2.5 px-4 border border-gray-300 rounded-md shadow-sm bg-white text-sm font-medium text-gray-700 hover:bg-gray-50">
                <GoogleIcon />
                <span className="ml-2">Sign in with Google</span>
            </button>
            <button onClick={() => onSsoLogin('Microsoft')} className="flex-1 flex items-center justify-center py-2.5 px-4 border border-gray-300 rounded-md shadow-sm bg-white text-sm font-medium text-gray-700 hover:bg-gray-50">
                <MicrosoftIcon />
                <span className="ml-2">Sign in with Microsoft</span>
            </button>
        </div>

         <div className="text-center mt-6">
            <p className="text-sm text-gray-600">
                Don't have an account?{' '}
                <button type="button" onClick={onNavigateToSignUp} className="font-medium text-brand-secondary hover:underline">
                    Sign up
                </button>
            </p>
         </div>
         <div className="text-center mt-2">
            <button type="button" onClick={handleAdminLoginClick} className="text-xs text-brand-gray hover:text-brand-secondary hover:underline">
              Admin Login
            </button>
         </div>
      </div>
       <p className="text-center text-sm text-gray-400 mt-8">&copy; 2024 Ace Legal Partners. All Rights Reserved.</p>
    </div>
  );
};

export default LoginView;